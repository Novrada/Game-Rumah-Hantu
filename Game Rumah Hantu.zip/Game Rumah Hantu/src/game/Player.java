package game;

/**
 *
 * @author naufa
 */
public class Player {
    public boolean keyGet, wereOnSecondFloor, readBook, takeBook;
}
